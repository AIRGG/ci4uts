<?= $this->extend('uts/templates/base_template') ?>

<?= $this->section('content') ?>
<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col">
                <h2>Dashboard</h2>
            </div>
        </div>
    </div>
    <div class="card-body">
        Ini adalah dashboard dengan rich content
    </div>
</div>
<?= $this->endSection() ?>
